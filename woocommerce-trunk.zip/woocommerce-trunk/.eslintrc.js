module.exports = {
	root: true,
	extends: [ 'plugin:@woocommerce/eslint-plugin/recommended' ],
};
