/**
 * Internal dependencies
 */
import { BasePage } from './BasePage';

export class Plugins extends BasePage {
	url = 'wp-admin/plugins.php';
}
