# Changelog

This project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

[See legacy changelogs for previous versions](https://github.com/woocommerce/woocommerce/blob/<last-commit-hash-before-this-merge>/packages/js/api/CHANGELOG.md).
