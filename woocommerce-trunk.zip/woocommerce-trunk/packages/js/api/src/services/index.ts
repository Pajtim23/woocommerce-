export { SettingService } from './setting-service';
