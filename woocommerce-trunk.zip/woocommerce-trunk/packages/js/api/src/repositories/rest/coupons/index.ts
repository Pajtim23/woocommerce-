/**
 * Internal dependencies
 */
import couponRESTRepository from './coupon';

export { couponRESTRepository };
