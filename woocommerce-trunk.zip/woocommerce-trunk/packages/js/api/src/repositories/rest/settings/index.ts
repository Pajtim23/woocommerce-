/**
 * Internal dependencies
 */
import settingRESTRepository from './setting';
import settingGroupRESTRepository from './setting-group';

export { settingRESTRepository, settingGroupRESTRepository };
