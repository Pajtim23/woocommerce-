module.exports = {
	extends: '../internal-js-tests/babel.config.js',
};
