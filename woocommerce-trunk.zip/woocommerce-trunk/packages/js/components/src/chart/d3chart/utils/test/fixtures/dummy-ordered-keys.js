export default [
	{
		key: 'Cap',
		focus: true,
		visible: true,
		total: 34513697,
	},
	{
		key: 'T-Shirt',
		focus: true,
		visible: true,
		total: 14762281,
	},
	{
		key: 'Sunglasses',
		focus: true,
		visible: true,
		total: 12430349,
	},
	{
		key: 'Polo',
		focus: true,
		visible: true,
		total: 8712807,
	},
	{
		key: 'Hoodie',
		focus: true,
		visible: true,
		total: 6968764,
	},
];
