export const smallBreak = 783;
export const wideBreak = 1365;
